import { useQuery } from "@tanstack/react-query";
import { AccountPackage } from "@shared/schema";
import { useCartStore } from "@/lib/cart-store";
import { useToast } from "@/hooks/use-toast";

export default function AccountPackages() {
  const { data: packages, isLoading } = useQuery<AccountPackage[]>({
    queryKey: ["/api/packages"],
  });
  
  const addItem = useCartStore(state => state.addItem);
  const { toast } = useToast();

  const handleAddToCart = (pkg: AccountPackage) => {
    addItem(pkg);
    toast({
      title: "Added to Cart",
      description: `${pkg.name} has been added to your cart.`,
    });
  };

  if (isLoading) {
    return (
      <section className="py-20 bg-gradient-to-b from-minecraft-black to-minecraft-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="text-minecraft-green font-pixel text-lg">Loading packages...</div>
          </div>
        </div>
      </section>
    );
  }

  if (!packages || packages.length === 0) {
    return (
      <section className="py-20 bg-gradient-to-b from-minecraft-black to-minecraft-gray">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="text-red-500 font-pixel text-lg">No packages available</div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="accounts" className="py-20 bg-gradient-to-b from-minecraft-black to-minecraft-gray">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-pixel text-minecraft-green text-2xl md:text-3xl mb-4" data-testid="packages-title">
            Account Packages
          </h2>
          <p className="text-gray-300 text-lg max-w-2xl mx-auto" data-testid="packages-description">
            Choose from our carefully curated selection of premium accounts
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {packages.map((pkg) => (
            <div 
              key={pkg.id} 
              className={`card-hover bg-minecraft-gray border-2 rounded-lg p-6 relative overflow-hidden ${
                pkg.isBestValue 
                  ? 'border-minecraft-bright transform scale-105' 
                  : pkg.name === 'VIP Account'
                  ? 'border-minecraft-gold'
                  : 'border-minecraft-green'
              }`}
              data-testid={`package-card-${pkg.id}`}
            >
              {pkg.isPopular && (
                <div className="absolute top-0 right-0 bg-minecraft-green text-black px-3 py-1 rounded-bl-lg font-pixel text-xs">
                  Popular
                </div>
              )}
              {pkg.isBestValue && (
                <div className="absolute top-0 right-0 bg-minecraft-bright text-black px-3 py-1 rounded-bl-lg font-pixel text-xs glow-animation">
                  Best Value
                </div>
              )}
              {pkg.name === 'VIP Account' && (
                <div className="absolute top-0 right-0 bg-minecraft-gold text-black px-3 py-1 rounded-bl-lg font-pixel text-xs">
                  VIP
                </div>
              )}
              
              <div className="text-center mb-6">
                <i className={`${pkg.icon} ${
                  pkg.isBestValue 
                    ? 'text-minecraft-bright' 
                    : pkg.name === 'VIP Account'
                    ? 'text-minecraft-gold'
                    : 'text-minecraft-green'
                } text-4xl mb-4`} data-testid={`package-icon-${pkg.id}`}></i>
                <h3 className="font-pixel text-white text-lg mb-2" data-testid={`package-name-${pkg.id}`}>
                  {pkg.name}
                </h3>
                <p className="text-gray-400 text-sm" data-testid={`package-description-${pkg.id}`}>
                  {pkg.description}
                </p>
              </div>
              
              <div className="text-center mb-6">
                <span className={`font-pixel text-3xl ${
                  pkg.isBestValue 
                    ? 'text-minecraft-bright' 
                    : pkg.name === 'VIP Account'
                    ? 'text-minecraft-gold'
                    : 'text-minecraft-green'
                }`} data-testid={`package-price-${pkg.id}`}>
                  ${pkg.price}
                </span>
                <span className="text-gray-400 text-sm block">one-time payment</span>
              </div>
              
              <ul className="space-y-3 mb-8">
                {pkg.features.map((feature, index) => (
                  <li key={index} className="flex items-center text-sm" data-testid={`package-feature-${pkg.id}-${index}`}>
                    <i className={`fas fa-check ${
                      pkg.isBestValue 
                        ? 'text-minecraft-bright' 
                        : pkg.name === 'VIP Account'
                        ? 'text-minecraft-gold'
                        : 'text-minecraft-green'
                    } mr-3`}></i>
                    {feature}
                  </li>
                ))}
              </ul>
              
              <button 
                onClick={() => handleAddToCart(pkg)}
                className={`minecraft-button w-full py-3 font-pixel text-xs ${
                  pkg.isBestValue 
                    ? 'text-minecraft-bright border-minecraft-bright' 
                    : pkg.name === 'VIP Account'
                    ? 'text-minecraft-gold border-minecraft-gold'
                    : 'text-minecraft-green'
                }`}
                data-testid={`button-add-cart-${pkg.id}`}
              >
                <i className="fas fa-shopping-cart mr-2"></i>
                Add to Cart
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
