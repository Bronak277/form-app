export default function HeroSection() {
  const scrollToAccounts = () => {
    const element = document.getElementById("accounts");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const scrollToFeatures = () => {
    const element = document.getElementById("features");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center">
      {/* Gaming setup background image */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080" 
          alt="Gaming setup with multiple monitors" 
          className="w-full h-full object-cover opacity-20"
          data-testid="hero-background-image"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-minecraft-black/50 to-minecraft-black/80"></div>
      </div>
      
      <div className="relative z-10 text-center max-w-4xl mx-auto px-4">
        <div className="float-animation mb-8">
          <i className="fas fa-cube text-minecraft-green text-6xl mb-4 glow-animation" data-testid="hero-icon"></i>
        </div>
        
        <h1 className="font-pixel text-white text-2xl md:text-4xl lg:text-5xl mb-6 leading-relaxed" data-testid="hero-title">
          Premium Minecraft Accounts
          <span className="text-minecraft-green block mt-2">At Unbeatable Prices</span>
        </h1>
        
        <p className="text-gray-300 text-lg md:text-xl mb-8 max-w-2xl mx-auto" data-testid="hero-description">
          Get instant access to premium Minecraft accounts with full features. Secure, reliable, and affordable gaming experience guaranteed.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <button 
            onClick={scrollToAccounts}
            className="minecraft-button px-8 py-4 font-pixel text-minecraft-green text-sm hover:text-minecraft-bright"
            data-testid="button-browse-accounts"
          >
            <i className="fas fa-play mr-2"></i>Browse Accounts
          </button>
          <button 
            onClick={scrollToFeatures}
            className="minecraft-button px-8 py-4 font-pixel text-minecraft-green text-sm hover:text-minecraft-bright"
            data-testid="button-learn-more"
          >
            <i className="fas fa-info-circle mr-2"></i>Learn More
          </button>
        </div>
        
        <div className="flex justify-center items-center space-x-8 mt-12">
          <div className="text-center">
            <div className="text-minecraft-green font-pixel text-2xl" data-testid="stats-customers">1,247</div>
            <div className="text-gray-400 text-sm">Happy Customers</div>
          </div>
          <div className="text-center">
            <div className="text-minecraft-green font-pixel text-2xl" data-testid="stats-support">24/7</div>
            <div className="text-gray-400 text-sm">Support</div>
          </div>
          <div className="text-center">
            <div className="text-minecraft-green font-pixel text-2xl" data-testid="stats-secure">100%</div>
            <div className="text-gray-400 text-sm">Secure</div>
          </div>
        </div>
      </div>
    </section>
  );
}
