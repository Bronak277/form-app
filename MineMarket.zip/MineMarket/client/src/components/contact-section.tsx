import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertContactMessageSchema } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { z } from "zod";

type ContactFormData = z.infer<typeof insertContactMessageSchema>;

export default function ContactSection() {
  const { toast } = useToast();
  
  const form = useForm<ContactFormData>({
    resolver: zodResolver(insertContactMessageSchema),
    defaultValues: {
      name: "",
      email: "",
      message: "",
    },
  });

  const contactMutation = useMutation({
    mutationFn: async (data: ContactFormData) => {
      return await apiRequest("POST", "/api/contact", data);
    },
    onSuccess: () => {
      toast({
        title: "Message Sent",
        description: "Thank you for your message! We'll get back to you soon.",
      });
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ContactFormData) => {
    contactMutation.mutate(data);
  };

  return (
    <section id="contact" className="py-20 bg-minecraft-black">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-pixel text-minecraft-green text-2xl md:text-3xl mb-4" data-testid="contact-title">
            Get in Touch
          </h2>
          <p className="text-gray-300 text-lg" data-testid="contact-description">
            Have questions? We're here to help you get started!
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <h3 className="font-pixel text-white text-lg mb-6" data-testid="contact-info-title">
              Contact Information
            </h3>
            <div className="space-y-4">
              <div className="flex items-center" data-testid="contact-email">
                <i className="fas fa-envelope text-minecraft-green mr-4"></i>
                <span>support@minecraftpremium.com</span>
              </div>
              <div className="flex items-center" data-testid="contact-hours">
                <i className="fas fa-clock text-minecraft-green mr-4"></i>
                <span>24/7 Support Available</span>
              </div>
              <div className="flex items-center" data-testid="contact-security">
                <i className="fas fa-shield-alt text-minecraft-green mr-4"></i>
                <span>Secure & Encrypted Communications</span>
              </div>
            </div>

            <div className="mt-8">
              <h4 className="font-pixel text-white text-sm mb-4" data-testid="social-title">Follow Us</h4>
              <div className="flex space-x-4">
                <a 
                  href="#" 
                  className="text-minecraft-green hover:text-minecraft-bright transition-colors"
                  data-testid="social-discord"
                >
                  <i className="fab fa-discord text-2xl"></i>
                </a>
                <a 
                  href="#" 
                  className="text-minecraft-green hover:text-minecraft-bright transition-colors"
                  data-testid="social-twitter"
                >
                  <i className="fab fa-twitter text-2xl"></i>
                </a>
                <a 
                  href="#" 
                  className="text-minecraft-green hover:text-minecraft-bright transition-colors"
                  data-testid="social-reddit"
                >
                  <i className="fab fa-reddit text-2xl"></i>
                </a>
              </div>
            </div>
          </div>

          <div>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6" data-testid="contact-form">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white text-sm font-medium">Name</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Your name"
                          {...field}
                          className="bg-minecraft-gray border-minecraft-green/30 text-white focus:border-minecraft-green"
                          data-testid="input-name"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white text-sm font-medium">Email</FormLabel>
                      <FormControl>
                        <Input
                          type="email"
                          placeholder="your@email.com"
                          {...field}
                          className="bg-minecraft-gray border-minecraft-green/30 text-white focus:border-minecraft-green"
                          data-testid="input-email"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white text-sm font-medium">Message</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="How can we help you?"
                          {...field}
                          rows={4}
                          className="bg-minecraft-gray border-minecraft-green/30 text-white focus:border-minecraft-green resize-none"
                          data-testid="textarea-message"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <Button
                  type="submit"
                  disabled={contactMutation.isPending}
                  className="minecraft-button w-full py-3 font-pixel text-minecraft-green text-xs bg-transparent"
                  data-testid="button-send-message"
                >
                  <i className="fas fa-paper-plane mr-2"></i>
                  {contactMutation.isPending ? "Sending..." : "Send Message"}
                </Button>
              </form>
            </Form>
          </div>
        </div>
      </div>
    </section>
  );
}
