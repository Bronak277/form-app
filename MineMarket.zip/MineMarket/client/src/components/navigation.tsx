import { useState, useEffect } from "react";
import { useCartStore } from "@/lib/cart-store";

export default function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [lastScrollY, setLastScrollY] = useState(0);
  const [navTransform, setNavTransform] = useState("translateY(0)");
  const totalItems = useCartStore(state => state.getTotalItems());

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      
      if (currentScrollY > lastScrollY && currentScrollY > 100) {
        setNavTransform("translateY(-100%)");
      } else {
        setNavTransform("translateY(0)");
      }
      
      setLastScrollY(currentScrollY);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [lastScrollY]);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
    setIsMenuOpen(false);
  };

  return (
    <nav 
      className="bg-minecraft-gray border-b-2 border-minecraft-green sticky top-0 z-50 transition-transform duration-300"
      style={{ transform: navTransform }}
      data-testid="navigation-main"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-3">
            <i className="fas fa-cube text-minecraft-green text-2xl" data-testid="logo-icon"></i>
            <span className="font-pixel text-minecraft-green text-lg" data-testid="logo-text">
              MineCraft Premium
            </span>
          </div>
          
          <div className="hidden md:flex space-x-8">
            <button 
              onClick={() => scrollToSection("home")}
              className="text-white hover:text-minecraft-green transition-colors"
              data-testid="nav-home"
            >
              Home
            </button>
            <button 
              onClick={() => scrollToSection("accounts")}
              className="text-white hover:text-minecraft-green transition-colors"
              data-testid="nav-accounts"
            >
              Accounts
            </button>
            <button 
              onClick={() => scrollToSection("features")}
              className="text-white hover:text-minecraft-green transition-colors"
              data-testid="nav-features"
            >
              Features
            </button>
            <button 
              onClick={() => scrollToSection("contact")}
              className="text-white hover:text-minecraft-green transition-colors"
              data-testid="nav-contact"
            >
              Contact
            </button>
          </div>
          
          <div className="flex items-center space-x-4">
            <button 
              className="minecraft-button px-4 py-2 font-pixel text-xs text-minecraft-green"
              data-testid="cart-button"
            >
              <i className="fas fa-shopping-cart mr-2"></i>
              Cart ({totalItems})
            </button>
            
            <button
              className="md:hidden text-white"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              data-testid="mobile-menu-toggle"
            >
              <i className={`fas ${isMenuOpen ? 'fa-times' : 'fa-bars'} text-xl`}></i>
            </button>
          </div>
        </div>
        
        {isMenuOpen && (
          <div className="md:hidden py-4 space-y-2" data-testid="mobile-menu">
            <button 
              onClick={() => scrollToSection("home")}
              className="block w-full text-left text-white hover:text-minecraft-green transition-colors py-2"
              data-testid="mobile-nav-home"
            >
              Home
            </button>
            <button 
              onClick={() => scrollToSection("accounts")}
              className="block w-full text-left text-white hover:text-minecraft-green transition-colors py-2"
              data-testid="mobile-nav-accounts"
            >
              Accounts
            </button>
            <button 
              onClick={() => scrollToSection("features")}
              className="block w-full text-left text-white hover:text-minecraft-green transition-colors py-2"
              data-testid="mobile-nav-features"
            >
              Features
            </button>
            <button 
              onClick={() => scrollToSection("contact")}
              className="block w-full text-left text-white hover:text-minecraft-green transition-colors py-2"
              data-testid="mobile-nav-contact"
            >
              Contact
            </button>
          </div>
        )}
      </div>
    </nav>
  );
}
