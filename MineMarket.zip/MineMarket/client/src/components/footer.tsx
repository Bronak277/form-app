export default function Footer() {
  return (
    <footer className="bg-minecraft-gray border-t-2 border-minecraft-green py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <i className="fas fa-cube text-minecraft-green text-2xl" data-testid="footer-logo-icon"></i>
              <span className="font-pixel text-minecraft-green text-lg" data-testid="footer-logo-text">
                MineCraft Premium
              </span>
            </div>
            <p className="text-gray-400 text-sm" data-testid="footer-description">
              Your trusted source for premium Minecraft accounts at unbeatable prices.
            </p>
          </div>
          
          <div>
            <h4 className="font-pixel text-white text-sm mb-4" data-testid="footer-products-title">Products</h4>
            <ul className="space-y-2 text-gray-400 text-sm">
              <li>
                <a href="#" className="hover:text-minecraft-green transition-colors" data-testid="footer-link-basic">
                  Basic Accounts
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-minecraft-green transition-colors" data-testid="footer-link-premium">
                  Premium Accounts
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-minecraft-green transition-colors" data-testid="footer-link-vip">
                  VIP Accounts
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-pixel text-white text-sm mb-4" data-testid="footer-support-title">Support</h4>
            <ul className="space-y-2 text-gray-400 text-sm">
              <li>
                <a href="#" className="hover:text-minecraft-green transition-colors" data-testid="footer-link-help">
                  Help Center
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-minecraft-green transition-colors" data-testid="footer-link-contact">
                  Contact Us
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-minecraft-green transition-colors" data-testid="footer-link-warranty">
                  Warranty
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-pixel text-white text-sm mb-4" data-testid="footer-legal-title">Legal</h4>
            <ul className="space-y-2 text-gray-400 text-sm">
              <li>
                <a href="#" className="hover:text-minecraft-green transition-colors" data-testid="footer-link-terms">
                  Terms of Service
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-minecraft-green transition-colors" data-testid="footer-link-privacy">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-minecraft-green transition-colors" data-testid="footer-link-refund">
                  Refund Policy
                </a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-minecraft-green/30 mt-8 pt-8 text-center">
          <p className="text-gray-400 text-sm" data-testid="footer-copyright">
            &copy; 2024 MineCraft Premium. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
