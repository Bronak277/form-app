import { useQuery } from "@tanstack/react-query";
import { Testimonial } from "@shared/schema";

export default function TestimonialsSection() {
  const { data: testimonials, isLoading } = useQuery<Testimonial[]>({
    queryKey: ["/api/testimonials"],
  });

  if (isLoading) {
    return (
      <section className="py-20 bg-gradient-to-b from-minecraft-gray to-minecraft-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="text-minecraft-green font-pixel text-lg">Loading testimonials...</div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-20 bg-gradient-to-b from-minecraft-gray to-minecraft-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-pixel text-minecraft-green text-2xl md:text-3xl mb-4" data-testid="testimonials-title">
            What Players Say
          </h2>
          <p className="text-gray-300 text-lg max-w-2xl mx-auto" data-testid="testimonials-description">
            Join thousands of satisfied customers who trust us for their gaming needs
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials?.map((testimonial) => (
            <div 
              key={testimonial.id} 
              className="bg-minecraft-gray p-6 rounded-lg border border-minecraft-green/30"
              data-testid={`testimonial-card-${testimonial.id}`}
            >
              <div className="flex items-center mb-4">
                <div className="w-10 h-10 bg-minecraft-green rounded-full flex items-center justify-center">
                  <i className="fas fa-user text-black" data-testid={`testimonial-avatar-${testimonial.id}`}></i>
                </div>
                <div className="ml-3">
                  <div className="font-semibold" data-testid={`testimonial-author-${testimonial.id}`}>
                    {testimonial.author}
                  </div>
                  <div className="flex text-minecraft-green text-sm" data-testid={`testimonial-rating-${testimonial.id}`}>
                    {Array.from({ length: testimonial.rating }, (_, i) => (
                      <i key={i} className="fas fa-star"></i>
                    ))}
                  </div>
                </div>
              </div>
              <p className="text-gray-300 text-sm" data-testid={`testimonial-content-${testimonial.id}`}>
                "{testimonial.content}"
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
