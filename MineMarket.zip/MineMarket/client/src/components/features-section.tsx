export default function FeaturesSection() {
  const features = [
    {
      icon: "fas fa-shield-alt",
      title: "100% Secure",
      description: "All accounts are thoroughly tested and verified before delivery"
    },
    {
      icon: "fas fa-bolt",
      title: "Instant Delivery",
      description: "Receive your account details immediately after payment"
    },
    {
      icon: "fas fa-headset",
      title: "24/7 Support",
      description: "Round-the-clock customer service for all your needs"
    },
    {
      icon: "fas fa-dollar-sign",
      title: "Best Prices",
      description: "Unbeatable prices without compromising on quality"
    }
  ];

  return (
    <section id="features" className="py-20 bg-minecraft-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-pixel text-minecraft-green text-2xl md:text-3xl mb-4" data-testid="features-title">
            Why Choose Us?
          </h2>
          <p className="text-gray-300 text-lg max-w-2xl mx-auto" data-testid="features-description">
            We provide the best Minecraft account experience with unmatched quality and support
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="text-center group" data-testid={`feature-card-${index}`}>
              <div className="bg-minecraft-gray p-6 rounded-lg border border-minecraft-green/30 group-hover:border-minecraft-green transition-colors mb-4">
                <i className={`${feature.icon} text-minecraft-green text-3xl mb-4`} data-testid={`feature-icon-${index}`}></i>
                <h3 className="font-pixel text-white text-sm mb-2" data-testid={`feature-title-${index}`}>
                  {feature.title}
                </h3>
                <p className="text-gray-400 text-xs" data-testid={`feature-description-${index}`}>
                  {feature.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
