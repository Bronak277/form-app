import { create } from "zustand";
import { AccountPackage } from "@shared/schema";

interface CartItem {
  package: AccountPackage;
  quantity: number;
}

interface CartStore {
  items: CartItem[];
  addItem: (pkg: AccountPackage) => void;
  removeItem: (packageId: string) => void;
  updateQuantity: (packageId: string, quantity: number) => void;
  getTotalItems: () => number;
  getTotalPrice: () => number;
  clearCart: () => void;
}

export const useCartStore = create<CartStore>((set, get) => ({
  items: [],
  
  addItem: (pkg: AccountPackage) => {
    const { items } = get();
    const existingItem = items.find(item => item.package.id === pkg.id);
    
    if (existingItem) {
      set({
        items: items.map(item =>
          item.package.id === pkg.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      });
    } else {
      set({
        items: [...items, { package: pkg, quantity: 1 }]
      });
    }
  },
  
  removeItem: (packageId: string) => {
    set({
      items: get().items.filter(item => item.package.id !== packageId)
    });
  },
  
  updateQuantity: (packageId: string, quantity: number) => {
    if (quantity <= 0) {
      get().removeItem(packageId);
      return;
    }
    
    set({
      items: get().items.map(item =>
        item.package.id === packageId
          ? { ...item, quantity }
          : item
      )
    });
  },
  
  getTotalItems: () => {
    return get().items.reduce((total, item) => total + item.quantity, 0);
  },
  
  getTotalPrice: () => {
    return get().items.reduce((total, item) => 
      total + (parseFloat(item.package.price) * item.quantity), 0
    );
  },
  
  clearCart: () => {
    set({ items: [] });
  }
}));
