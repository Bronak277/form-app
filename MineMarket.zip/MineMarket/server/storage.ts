import { 
  type AccountPackage, 
  type InsertAccountPackage,
  type Testimonial,
  type InsertTestimonial,
  type ContactMessage,
  type InsertContactMessage,
  type Order,
  type InsertOrder
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Account Packages
  getAccountPackages(): Promise<AccountPackage[]>;
  getAccountPackage(id: string): Promise<AccountPackage | undefined>;
  createAccountPackage(pkg: InsertAccountPackage): Promise<AccountPackage>;

  // Testimonials
  getTestimonials(): Promise<Testimonial[]>;
  createTestimonial(testimonial: InsertTestimonial): Promise<Testimonial>;

  // Contact Messages
  createContactMessage(message: InsertContactMessage): Promise<ContactMessage>;

  // Orders
  createOrder(order: InsertOrder): Promise<Order>;
  getOrder(id: string): Promise<Order | undefined>;
}

export class MemStorage implements IStorage {
  private packages: Map<string, AccountPackage>;
  private testimonials: Map<string, Testimonial>;
  private contactMessages: Map<string, ContactMessage>;
  private orders: Map<string, Order>;

  constructor() {
    this.packages = new Map();
    this.testimonials = new Map();
    this.contactMessages = new Map();
    this.orders = new Map();
    
    this.seedInitialData();
  }

  private seedInitialData() {
    // Seed account packages
    const packages: InsertAccountPackage[] = [
      {
        name: "Basic Account",
        description: "Perfect for casual players",
        price: "4.99",
        features: ["Full Minecraft access", "Multiplayer compatible", "Instant delivery", "24h warranty"],
        isPopular: true,
        isBestValue: false,
        icon: "fas fa-user",
        warranty: "24h warranty"
      },
      {
        name: "Premium Account",
        description: "Enhanced gaming experience",
        price: "7.99",
        features: ["Everything in Basic", "Custom username", "Skin access", "7-day warranty", "Priority support"],
        isPopular: false,
        isBestValue: true,
        icon: "fas fa-crown",
        warranty: "7-day warranty"
      },
      {
        name: "VIP Account",
        description: "Ultimate gaming package",
        price: "12.99",
        features: ["Everything in Premium", "Rare username", "Cape access", "30-day warranty", "VIP support channel"],
        isPopular: false,
        isBestValue: false,
        icon: "fas fa-gem",
        warranty: "30-day warranty"
      }
    ];

    packages.forEach(pkg => {
      this.createAccountPackage(pkg);
    });

    // Seed testimonials
    const testimonials: InsertTestimonial[] = [
      {
        author: "Steve_Miner",
        content: "Amazing service! Got my account instantly and it works perfectly. Great prices too!",
        rating: 5
      },
      {
        author: "CraftMaster99",
        content: "Been using their service for months. Super reliable and great customer support!",
        rating: 5
      },
      {
        author: "BlockBuilder",
        content: "Best place to get premium accounts! Fast, secure, and affordable. Highly recommend!",
        rating: 5
      }
    ];

    testimonials.forEach(testimonial => {
      this.createTestimonial(testimonial);
    });
  }

  async getAccountPackages(): Promise<AccountPackage[]> {
    return Array.from(this.packages.values());
  }

  async getAccountPackage(id: string): Promise<AccountPackage | undefined> {
    return this.packages.get(id);
  }

  async createAccountPackage(insertPackage: InsertAccountPackage): Promise<AccountPackage> {
    const id = randomUUID();
    const pkg: AccountPackage = { ...insertPackage, id };
    this.packages.set(id, pkg);
    return pkg;
  }

  async getTestimonials(): Promise<Testimonial[]> {
    return Array.from(this.testimonials.values());
  }

  async createTestimonial(insertTestimonial: InsertTestimonial): Promise<Testimonial> {
    const id = randomUUID();
    const testimonial: Testimonial = { ...insertTestimonial, id };
    this.testimonials.set(id, testimonial);
    return testimonial;
  }

  async createContactMessage(insertMessage: InsertContactMessage): Promise<ContactMessage> {
    const id = randomUUID();
    const message: ContactMessage = { 
      ...insertMessage, 
      id,
      createdAt: new Date()
    };
    this.contactMessages.set(id, message);
    return message;
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = randomUUID();
    const order: Order = {
      ...insertOrder,
      id,
      createdAt: new Date()
    };
    this.orders.set(id, order);
    return order;
  }

  async getOrder(id: string): Promise<Order | undefined> {
    return this.orders.get(id);
  }
}

export const storage = new MemStorage();
